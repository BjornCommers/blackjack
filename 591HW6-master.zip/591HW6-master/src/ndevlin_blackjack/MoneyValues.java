package ndevlin_blackjack;

public enum MoneyValues {
	five, ten, twenty, fifty, hundred
}
