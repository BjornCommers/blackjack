package ndevlin_blackjack;

public enum BillSize {
	
Lincoln, Hamilton, Jackson, Grant, Franklin  

}
